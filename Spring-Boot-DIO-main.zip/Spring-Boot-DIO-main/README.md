# Projeto Dio Sistema Ponto de Acesso
Construindo um sistema de controle de ponto e acesso com Spring Boot

<h3>Contrução de Api rest para gerenciamento de ponto e controle de acesso, utilizando:</h3
*Java <br>
*Gradle <br>
*Spring Data Jpa<br>
*Hibernate <br>
*swagger <br>
*Lombok.
